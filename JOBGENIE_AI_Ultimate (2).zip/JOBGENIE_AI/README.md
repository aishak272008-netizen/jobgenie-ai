# JOBGENIE AI — Ultimate starter

A responsive, installable web app (PWA) with Capacitor wrappers for Android and iOS. It includes a career dashboard, resume drafting, interview coaching, career roadmap, career chat, sample job explorer, bilingual UI labels (English/Hindi), local profile storage, and a premium pricing preview.

## Important truth about this build

- This is a working starter/MVP, not a finished commercial service.
- AI tools work in **demo mode** until you add your own server-side `OPENAI_API_KEY`.
- The job cards are sample data, not live vacancies. Connect a licensed/approved job feed before advertising them as current jobs.
- Premium checkout is a preview only. No payments are collected. Add a payment provider, server-side order creation, signature verification, webhooks, refunds and tax handling before launch.
- The UI is bilingual at the navigation/welcome level; generated content and all screens are not fully translated yet.
- Do not promise a job or claim that AI-generated resume details are verified.

## Requirements

Node.js 20+ and npm. For Android builds, install Android Studio and its Android SDK. For iOS builds, you need macOS with Xcode. An iPhone app cannot be built or signed locally on Windows.

## Run locally

```bash
npm install
cp .env.example .env
# Optional: put your API key in .env on the server only
npm run dev
```

Open http://localhost:5173. The API server runs on http://localhost:3000. The frontend uses `/api/ai`; configure a same-origin reverse proxy or serve the built `dist` from the Express server for production.

## Production server

```bash
npm run build
NODE_ENV=production npm start
```

Set `OPENAI_API_KEY` and optionally `OPENAI_MODEL` in your hosting provider's **server environment settings**. Never place the key in `src/`, `public/`, `VITE_*`, a mobile bundle, GitHub, or screenshots. The Express server serves `dist` in production.

## Android and iOS with Capacitor

```bash
npm install
npx cap add android
npx cap add ios
npm run cap:sync
npx cap open android
# On macOS only:
npx cap open ios
```

Build the Android App Bundle (AAB) in Android Studio: **Build → Generate Signed Bundle / APK → Android App Bundle**. Create and protect your upload key. For iOS, open the generated project in Xcode, configure signing and bundle ID, then Archive and upload through Xcode/Transporter. You need a Mac for the iOS build/signing step.

For native builds, set `VITE_API_BASE_URL=https://your-api-host.example` before building so the app calls your deployed backend rather than a local `/api` path. This value is a public API origin, not a secret. Rebuild after changing it and test on real devices before submission.

## Zero-budget launch path

1. First publish the PWA/web version using a free static host (for example GitHub Pages for frontend-only demo mode, or a free web-service tier for the Express server; free tiers and limits can change).
2. Share it with a small group and validate that users actually want the resume/interview tools.
3. Keep AI demo mode until you can afford API usage. Model API calls are usage-billed and are not included in the free app hosting.
4. Add a privacy policy, terms, support contact, data deletion path, and real job-source disclosures.
5. Only pay store registration fees after validating demand.

## Store fees and publishing

- Google Play full distribution currently requires a **US$25 one-time developer registration fee**. Google may require identity verification and additional testing for some new personal accounts. Official guide: https://support.google.com/googleplay/android-developer/answer/6112435
- Apple App Store distribution requires Apple Developer Program membership, currently **US$99 per year** (regional/local pricing may vary). India enrollment is through the Apple Developer app. Official guide: https://developer.apple.com/help/account/membership/program-enrollment/
- Therefore, public distribution on both stores is **not genuinely ₹0**. You can test the PWA free and use platform-specific free/local testing routes, but store publication has fees.

### Google Play checklist

1. Create a Google Play Console account and complete identity verification.
2. Create the app listing: JOBGENIE AI; choose category and contact details.
3. Prepare app icon, screenshots, short/full descriptions and support/privacy URLs.
4. Build a signed `.aab` from Android Studio.
5. Complete Data safety, content rating, target audience, ads and app access declarations accurately.
6. Upload to internal testing first; invite testers and fix issues.
7. Complete any required closed testing for your account, then apply for production access and submit for review.
8. Keep signing credentials private and back them up securely.

### Apple App Store checklist

1. Enroll in the Apple Developer Program using the Apple Developer app in India.
2. Create the app record in App Store Connect; use bundle ID `com.jobgenieai.app` or your own unique ID.
3. In Xcode, set signing team, version, build number, icons and privacy details.
4. Archive the iOS app and upload it to App Store Connect.
5. Add screenshots, description, support URL, privacy policy, age rating and App Privacy answers.
6. Test with TestFlight, fix issues and submit for App Review.
7. Follow Apple's rules for digital subscriptions and in-app purchases. Do not assume an external checkout is permitted for digital features.

## Monetization plan

Suggested experiment, not guaranteed earnings:
- Free: limited resume drafts and basic career tools.
- Plus: test ₹99/month or ₹699/year after validating willingness to pay.
- One-time products: resume review or interview preparation pack.
- B2B: college placement-cell licenses.

Before charging, add:
- Real payment provider integration (for India, evaluate Razorpay; check current eligibility and fees).
- Server-created payment orders; verify signatures and webhook events on the server.
- Subscription cancellation, refunds, invoices, GST/tax and customer support flows.
- Usage limits and abuse protection for AI requests.
- Transparent pricing and no misleading earning/job guarantees.

## Security and privacy launch checklist

- Keep API keys only in host environment variables.
- Add authentication, rate limiting, request size limits and abuse monitoring.
- Add a clear privacy policy and consent before collecting personal data.
- Provide account/data deletion and retention rules.
- Avoid collecting Aadhaar, PAN, passwords or sensitive personal data.
- Resume content can contain personal data; do not store or log it unnecessarily.
- Verify employers and job links before publishing job listings.
- Add accessibility checks and test on Android/iOS devices.

## Project structure

```text
JOBGENIE_AI/
  public/              PWA manifest and app icon
  server/index.js      Express API; OpenAI key stays server-side
  src/main.jsx         React app and feature screens
  src/styles.css       Responsive dark UI
  capacitor.config.ts  Android/iOS wrapper configuration
  .env.example         Environment variable template
```

## Next development milestones

1. Add login, database, saved resumes and user data deletion.
2. Integrate trusted job listings with source attribution and application links.
3. Add robust native share/export and PDF generation.
4. Add payments and subscription entitlements.
5. Add analytics with consent, crash reporting, accessibility and store policy checks.

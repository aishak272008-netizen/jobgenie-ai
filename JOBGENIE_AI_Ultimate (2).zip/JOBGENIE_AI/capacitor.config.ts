import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.jobgenieai.app',
  appName: 'JOBGENIE AI',
  webDir: 'dist',
  bundledWebRuntime: false
};
export default config;
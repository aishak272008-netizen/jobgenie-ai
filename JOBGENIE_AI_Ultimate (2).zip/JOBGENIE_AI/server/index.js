import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import OpenAI from "openai";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();
const app = express();
const port = process.env.PORT || 3000;
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use(cors({ origin: process.env.CLIENT_ORIGIN?.split(",") || true }));
app.use(express.json({ limit: "1mb" }));

app.get("/api/health", (_req, res) => res.json({ ok: true, app: "JOBGENIE AI" }));

app.post("/api/ai", async (req, res) => {
  const { task, input } = req.body || {};
  const allowed = ["resume", "cover-letter", "interview", "career-plan", "career-chat"];
  if (!allowed.includes(task) || typeof input !== "string" || input.trim().length < 3) {
    return res.status(400).json({ error: "Please provide a valid task and enough details." });
  }
  if (!process.env.OPENAI_API_KEY) {
    return res.status(503).json({ error: "AI is in demo mode. Add OPENAI_API_KEY to the server environment to enable live AI." });
  }
  try {
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const instructions = {
      resume: "Act as an expert resume writer. Create an ATS-friendly resume draft using only facts provided. Never invent qualifications, employers, dates or metrics. Mark missing details with [ADD DETAILS].",
      "cover-letter": "Write a concise, tailored professional cover letter. Do not invent experience. Use placeholders for missing facts.",
      interview: "Act as a supportive interview coach. Give one realistic interview question, then evaluate the supplied answer with strengths, improvements and a stronger example. Be constructive.",
      "career-plan": "Create a realistic 30-day career roadmap with weekly goals, daily actions, free learning suggestions by topic, and measurable outcomes. Do not fabricate links.",
      "career-chat": "Be a practical career mentor. Answer clearly, safely and honestly. Ask for missing context only when needed."
    };
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      instructions: instructions[task],
      input: input.trim()
    });
    res.json({ text: response.output_text || "No response generated." });
  } catch (err) {
    console.error("AI request failed:", err.message);
    res.status(500).json({ error: "AI request failed. Check the server logs and API configuration." });
  }
});

if (process.env.NODE_ENV === "production") {
  const dist = path.resolve(__dirname, "../dist");
  app.use(express.static(dist));
  app.get("*", (_req, res) => res.sendFile(path.join(dist, "index.html")));
}
app.listen(port, () => console.log(`JOBGENIE AI server running on port ${port}`));